% *******************************************************************
%  $Source: /iwi200/home/users/roe/matlab/development/RCS/sidwt.m,v $
%  $Revision: 1.2 $
%  $Date: 2005/03/23 09:25:36 $
%  $State: Exp $
%  $Author: roe $
% 
% *******************************************************************

function [f] = isidwt(yl,yh,h,g,level);

%  Computes the inverse undecimated discrete wavelet transform of a vector f
%  using the orthonormal wavelets defined by the coefficients H (See
%  DAUBECHIES). The number of elements in yl must be a power of 2
%  Input are low and highpass results stored in vectors yl and yh as :
%
%              k          
%       yl = [H f]
%                   2           k-1        
%       yh = [Gf; GH f;  ...; GH   f; ]
%
%  where H is a low pass filter, and G is the band-pass quadrature
%  mirror filter constructed from H.
%
%  Author: Jos Roerdink

len = length(yl); %Length output signal

if (len<2^level)
  error(sprintf('length too small')); 
end

% check for a power of 2
if (~isint(len/(2^level)))
  error(sprintf('cannot decompose signal of length %d to level %d',len,level));  
  return;
end

% Do the reconstruction

loh = length(h);
% Rescale reconstruction filters
h=h/2;
g=g/2;

f = yl; % Initialize f with low pass result

for j=level:-1:1,

  % Upsample filters
  p=2^(j-1);
  % Compute newlength of filters
  nl = p*loh;
  % Upsample filters by factor 2^j
  hup=zeros(1,nl);
  gup=zeros(1,nl);
  hup(1:p:nl)=h(1:1:loh);
  gup(1:p:nl)=g(1:1:loh);

  d= yh(1+(j-1)*len:j*len); % Detail signal

  % Extend signals periodically to the left
  % All signals have length len
  % All filters have length nl=p*loh
  f(nl:len+nl-1)=f;
  f(1:nl-1) = f(len+1:len+nl-1);
  d(nl:len+nl-1)=d;
  d(1:nl-1) = d(len+1:len+nl-1);

  % Filter
  f = filter(hup,1,f) + filter(gup,1,d);
  % Reduce output to size before periodic extension
  f = f(nl:len+nl-1);

end
