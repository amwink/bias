% *******************************************************************
%  $Source: /iwi200/home/users/roe/matlab/development/RCS/rwt_test.m,v $
%  $Revision: 1.2 $
%  $Date: 2005/03/29 12:02:18 $
%  $State: Exp $
%  $Author: roe $
% 
% *******************************************************************

function rwt_test (M, N,level)

% M: size input vector
% N: order daubechies wavelet
% level: level of decomposition 

% clear; M=16; N=1; level = 3;

[h,g]=daubechies(N);	% daubechies wavelet used

%x=rand(M,1).'

%x = [1 2 3 4 5 6 7 8]
%x = [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16]
x = [1 2 3 4]
%h=[1 2 3 4]

lox = length(x);
loh = length(h);
log = length(g);

L=level;
[yl,yh,L] = mrdwt(x,h,L);
yl
yh

% Inverse

[xrec,L] = mirdwt(yl,yh,h,L);
xrec
