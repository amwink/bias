% *******************************************************************
%  $Source: /iwi200/home/users/roe/matlab/development/RCS/fsidwt.m,v $
%  $Revision: 1.3 $
%  $Date: 2005/03/29 13:05:44 $
%  $State: Exp $
%  $Author: roe $
% 
% *******************************************************************

function [YL,YH]=fsidwt(h,g,C,level);

%  Computes the shift invariant wavelet transform in the frequency domain
%  C is the input vector in the Fourier domain.
%  The orthonormal wavelets defined by the coefficients H (See
%  DAUBECHIES) are used. The length of C must be a power of 2
%
%  The results are stored in vectors YL and YH as :
%                k
%       YL = [F(H f)]
%                        2              k-1
%       YH = [F(Gf); F(GH f);  ...; F(GH   f); ]
%
%  where F( ) denotes Fourier Transform, H is a low pass filter, 
%  and G is the band-pass quadrature mirror filter constructed from H.
%
%  Author: Jos Roerdink

C = C(:).';	% Convert to row form. Note the use of .', since C is complex

% Check length for a power of 2
len = length(C);

if (len<2^level)
  error(sprintf('length too small'));
end

% check for a power of 2
if (~isint(len/(2^level)))
error(sprintf('cannot decompose signal of length %d to level %d',len,level));
end

loh = length(h);
log = length(g);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

YL = zeros(1,len);    		% space for low pass result
YH = zeros(1,level*len);    	% space for high pass result

if (loh~=len) % filters not yet in freq.domain
  Hfull = len*ifft(h,len);	% Initial IFFT (we need dual filters)
  Gfull = len*ifft(g,len);  
else % filters in freq.domain
  Hfull = h(:)';
  Gfull = g(:)';
end  

size(h);

H=Hfull;
G=Gfull;

for j=1:level,
  Q=2^(j-1);			% sampling factor
  blocksize=len/Q;		% block size

  % Downsample filters
  H=Hfull(1:Q:len);	
  G=Gfull(1:Q:len);

  % Split C into Q equal blocks ("polyphase"), multiply each block with H and G
  % and assemble the results in vectors D and C ("monophase") 
 
  for q=1:Q,
    blockrange=1+(q-1)*blocksize:q*blocksize;
    D(blockrange) = G.*C(blockrange);
    C(blockrange) = H.*C(blockrange);
  end

  %D=D.*G;
  %C=C.*H;
  %H=[H(1:2:end) H(1:2:end)];
  %G=[G(1:2:end) G(1:2:end)];

% Put result for D in YH
  YH(1+(j-1)*len:j*len) = D;

end
            
YL(1:len) = C;
