% *******************************************************************
%  $Source: /iwi200/home/users/roe/matlab/development/RCS/sidwt.m,v $
%  $Revision: 1.3 $
%  $Date: 2005/03/29 12:02:20 $
%  $State: Exp $
%  $Author: roe $
% 
% *******************************************************************

function [yl,yh] = sidwt(h,g,f,level)

% [YL,YH] = SIDWT(H,F,K)
%  Computes the undecimated discrete wavelet transform using the
%  orthonormal wavelets defined by the coefficients H (See
%  DAUBECHIES). The length of f must be a power of 2
%
%  The results are stored in vectors yl and yh as :
%
%              k          
%       yl = [H f]
%                   2           k-1        
%       yh = [Gf; GH f;  ...; GH   f; ]
%
%  where H is a low pass filter, and G is the band-pass quadrature
%  mirror filter constructed from H.
%
%  Author: Jos Roerdink

len = length(f);

if (len<2^level)
  error(sprintf('length too small')); 
end

% check for a power of 2
if (~isint(len/(2^level)))
  error(sprintf('cannot decompose signal of length %d to level %d',len,level));  
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5

loh = length(h);
% Now flip h and g to use with filter.
  h = h(loh:-1:1);
  g = g(loh:-1:1);

% Do the k-level decomposition

  yl = zeros(1,len);		% low pass result
  yh = zeros(1,level*len);	% high pass result

for j=1:level,

  % Upsample filters
  p=2^(j-1);
  % Compute newlength of filters
  nl = p*loh;
  % Upsample filters by factor 2^j
  hup=zeros(1,nl);
  gup=zeros(1,nl);
  % Insert original filter values starting at position 1
  hup(1:p:nl)=h(1:1:loh);
  gup(1:p:nl)=g(1:1:loh);

  % Extend signal f periodically to the right
  % All filters have length nl=p*loh
  f(len+1:len+nl-1) = f(1:nl-1);

  % Filter
  d = filter(gup,1,f);
  f = filter(hup,1,f);
  % Reduce output to size before periodic extension
  % Offset is chosen to get agreement with rwt
  offset=p*(loh-1)+1;
  d = d(offset:offset+len-1);
  f = f(offset:offset+len-1);

  %Put result for d in yh
  yh(1+(j-1)*len:j*len) = d;

end

yl(1:len) = f;
