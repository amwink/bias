% *******************************************************************
%  $Source: /iwi200/home/users/roe/matlab/development/RCS/fisidwt.m,v $
%  $Revision: 1.3 $
%  $Date: 2005/03/29 13:05:43 $
%  $State: Exp $
%  $Author: roe $
% 
% *******************************************************************

function [C] = fisidwt(YL,YH,h,g,level);
%  Computes the inverse shift invariant wavelet transform 
%  in the frequency domain
%  YL,YH are the input vectors in the Fourier domain.
%  The orthonormal wavelets defined by the coefficients H (See
%  DAUBECHIES) are used. The length of YL must be a power of 2
%
%  The input vectors are:
%
%                k
%       YL = [F(H f)]
%                        2              k-1
%       YH = [F(Gf); F(GH f);  ...; F(GH   f); ]
%
%  where F( ) denotes Fourier Transform, H is a low pass filter, 
%  and G is the band-pass quadrature mirror filter constructed from H.
%
%  Author: Jos Roerdink


% Check length for a power of 2

len = length(YL);

if (len<2^level)
  error(sprintf('length too small'));
end

% check for a power of 2
if (~isint(len/(2^level)))
error(sprintf('cannot decompose signal of length %d to level %d',len,level));
end

loh = length(h);
% Rescale reconstruction filters
h=h/2;
g=g/2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (loh~=len) % filters not yet in freq.domain
  Hfull = fft(h,len);	% Initial full size FFT
  Gfull = fft(g,len);
else % filters in freq.domain
  Hfull = conj(h(:))';
  Gfull = conj(g(:))';
end;

C=YL;				% Initialize C with low pass result

for j=level:-1:1,

  Q=2^(j-1);			% sampling factor
  blocksize=len/Q;		% block size

% Downsample filters
  H=Hfull(1:Q:len);	
  G=Gfull(1:Q:len);

  D= YH(1+(j-1)*len:j*len); 	% Detail signal at level j

% Split C and D into Q equal blocks ("polyphase"), multiply each block 
% with H and G and add the results to get new vector C ("monophase")
  
  for q=1:Q,
    blockrange=1+(q-1)*blocksize:q*blocksize;
    C(blockrange) = H.*C(blockrange) + G.*D(blockrange);
  end

end
