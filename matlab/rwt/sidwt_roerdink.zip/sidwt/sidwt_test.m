% *******************************************************************
%  $Source: /iwi200/home/users/roe/matlab/development/RCS/sidwt_test.m,v $
%  $Revision: 1.3 $
%  $Date: 2005/03/29 13:05:45 $
%  $State: Exp $
%  $Author: roe $
% 
% *******************************************************************

function sidwt_test (M, N,level)

% M: size input vector
% N: order daubechies wavelet
% level: level of decomposition 

% clear; M=16; N=1; level = 3;

h=dbaux(N)*sqrt(2);	% daubechies wavelet used
g=qmf(h);

x=rand(M,1).'; %'
%x = [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16];

len = length(x);

L=level;
[yl,yh] = sidwt(h,g,x,L);

% Do it in the Fourier domain
X = fft(x);
[YL,YH]=fsidwt(h,g,X,L);

% Do inverse FFTs to check the results
yl_fft=real(ifft(YL));
for j=1:level,
  D = YH(1+(j-1)*len:j*len);
  d = real(ifft(D));
  yh_fft(1+(j-1)*len:j*len)= d;
end

  yl;
yl_fft;
yh;
yh_fft;

% Inverse shift-invariant dwt

[xrec] = isidwt(yl,yh,h,g,L);
xrec;

% Inverse shift-invariant dwt in Fourier domain
[XREC] = fisidwt(YL,YH,h,g,L);
xrec_fft = real(ifft(XREC));

plot([x(:) xrec_fft(:)]); 
sum(abs(x(:)-xrec_fft(:)))
